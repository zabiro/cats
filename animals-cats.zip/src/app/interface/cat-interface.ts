
export interface CatsInformation {
    
    name:                string;
    origin:              string;
    affection_level:     number;
    intelligence:        number; 
    reference_image_id:        string; 
    
}

